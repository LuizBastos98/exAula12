/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package Aplication;
import java.util.Scanner;
import Entities.Student;
import java.util.Locale;

/**
 *
 * @author Luiz Bastos <luizfelipebastossantana@gmail.com>
 * @date 19/03/2024
 * @brief Class Program
 */
public class Program {
public static void main(String[] args) {
        Locale.setDefault(Locale.US);
        Scanner sc = new Scanner(System.in);
        String name;
        double grade1, grade2, grade3;
        boolean test;

        System.out.print("Enter the student's name: ");
        name = sc.nextLine();

        do {
            System.out.print("Enter the grade for the first quarter (maximum value: 30): ");
            grade1 = sc.nextDouble();

            System.out.print("Enter the second quarter grade (maximum value: 35): ");
            grade2 = sc.nextDouble();

            System.out.print("Enter the third quarter grade (maximum value: 35): ");
            grade3 = sc.nextDouble();
            System.out.println("");
            System.out.println("");
            System.out.println("");

            test = validateG(grade1, grade2, grade3);
            if (!test) {
                System.out.println("As notas devem estar dentro do intervalo permitido.");
                sc.nextLine(); // Limpar o buffer do teclado
            }
        } while (!test);

        Student student = new Student(name, grade1, grade2, grade3);
        double finalG = student.calFinalG();
        String result = student.isPassing();

        System.out.println("FINAL GRADE = " + String.format("%.2f", finalG));
        System.out.println(result);

    }

    public static boolean validateG(double grade1, double grade2, double grade3) {
        return (grade1 >= 0 && grade1 <= 30) && (grade2 >= 0 && grade2 <= 35) && (grade3 >= 0 && grade3 <= 35);
    }

}